import React from 'react'
import './wishlist.css';
import shirt from "../../assets/images/shirt1.png"
import laptop from "../../assets/images/laptop.webp"
import chair from "../../assets/images/chair.webp"
import mouse from "../../assets/images/mouse.webp"
import chanel from "../../assets/images/chanel.webp"
import scent from "../../assets/images/scent.webp"
import { Cart, Dash, Plus,Trash3 } from 'react-bootstrap-icons';
import { Top } from '../header1/top.component';
import { Header } from '../header2/header.component';
import { MainNav } from '../mainnav3/mainnav.component';
import { Footer } from '../footer14/footer.component';
export const Wishlist = () => {
    return (
        <>
            <Top></Top>
            <Header></Header>
            <MainNav></MainNav>
            <section className="mt-5">
                <div className=" aboutdiv ">
                    <div>
                        <h1>Wishlist Page</h1>
                    </div>
                </div>
            </section>
            <div className='wishlist'>
                <table class="table table-bordered">
                    <thead className='table-light'>
                        <tr>
                            <th scope="col">Product Name</th>
                            <th scope="col">Unite Price</th>
                            <th scope="col">Quantity</th>
                            <th scope="col">Total Price</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td className='wl1'>
                                <div className='wl_img1'>
                                    <img src={shirt} style={{ width: '100px' }} alt="" />
                                </div>
                                <div>
                                    <h5>Yves Saint</h5>
                                    <p>Size:Large,</p>
                                </div>
                            </td>
                            <td>
                                <div className='center'><span className='rupee'>&#x20B9;1000</span></div>
                            </td>
                            <td>
                                <div className='flex_wl'>
                                    <span><Dash></Dash></span>
                                    <span>5</span>
                                    <span><Plus></Plus></span>
                                </div>
                            </td>
                            <td>
                                <div className='center'><span className='rupee'>&#x20B9;5000</span></div>
                            </td>
                            <td>
                                <div className='span_class'>
                                    <span className='span1 child1'><Cart></Cart></span>
                                    <span className='span1 child2'><Trash3></Trash3></span>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td className='wl1'>
                                <div className='wl_img1'>
                                    <img src={laptop} style={{ width: '100px' }} alt="" />
                                </div>
                                <div>
                                    <h5>Titanpro <br /> Gaming</h5>
                                    <h5>Laptop</h5>
                                </div>
                            </td>
                            <td>
                                <div className='center'><span className='rupee'>&#x20B9;100000</span></div>
                            </td>
                            <td>
                                <div className='flex_wl'>
                                    <span><Dash></Dash></span>
                                    <span>4</span>
                                    <span><Plus></Plus></span>
                                </div>
                            </td>
                            <td>
                                <div className='center'><span className='rupee'>&#x20B9;400000</span></div>
                            </td>
                            <td>
                                <div className='span_class'>
                                    <span className='span1 child1'><Cart></Cart></span>
                                    <span className='span1 child2'><Trash3></Trash3></span>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td className='wl1'>
                                <div className='wl_img1'>
                                    <img src={chair} style={{ width: '100px' }} alt="" />
                                </div>
                                <div>
                                    <h5>Hallroom</h5>
                                    <h5>Chair</h5>
                                </div>
                            </td>
                            <td>
                                <div className='center'><span className='rupee'>&#x20B9;2500</span></div>
                            </td>
                            <td>
                                <div className='flex_wl'>
                                    <span><Dash></Dash></span>
                                    <span>10</span>
                                    <span><Plus></Plus></span>
                                </div>
                            </td>
                            <td>
                                <div className='center'><span className='rupee'>&#x20B9;25000</span></div>
                            </td>
                            <td>
                                <div className='span_class'>
                                    <span className='span1 child1'><Cart></Cart></span>
                                    <span className='span1 child2'><Trash3></Trash3></span>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td className='wl1'>
                                <div className='wl_img1'>
                                    <img src={mouse} style={{ width: '100px' }} alt="" />
                                </div>
                                <div>
                                    <h5>Swiftglide</h5>
                                    <h5>Precision</h5>
                                    <h5>Mouse</h5>
                                </div>
                            </td>
                            <td>
                                <div className='center'><span className='rupee'>&#x20B9;500</span></div>
                            </td>
                            <td>
                                <div className='flex_wl'>
                                    <span><Dash></Dash></span>
                                    <span>3</span>
                                    <span><Plus></Plus></span>
                                </div>
                            </td>
                            <td>
                                <div className='center'><span className='rupee'>&#x20B9;1500</span></div>
                            </td>
                            <td>
                                <div className='span_class'>
                                    <span className='span1 child1'><Cart></Cart></span>
                                    <span className='span1 child2'><Trash3></Trash3></span>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td className='wl1'>
                                <div className='wl_img1'>
                                    <img src={chanel} style={{ width: '100px' }} alt="" />
                                </div>
                                <div>
                                    <h5>Maison</h5>
                                    <h5>Fransis</h5>
                                </div>
                            </td>
                            <td>
                                <div className='center'><span className='rupee'>&#x20B9;1000</span></div>
                            </td>
                            <td>
                                <div className='flex_wl'>
                                    <span><Dash></Dash></span>
                                    <span>7</span>
                                    <span><Plus></Plus></span>
                                </div>
                            </td>
                            <td>
                                <div className='center'><span className='rupee'>&#x20B9;7000</span></div>
                            </td>
                            <td>
                                <div className='span_class'>
                                    <span className='span1 child1'><Cart></Cart></span>
                                    <span className='span1 child2'><Trash3></Trash3></span>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td className='wl1'>
                                <div className='wl_img1'>
                                    <img src={scent} style={{ width: '100px' }} alt="" />
                                </div>
                                <div>
                                    <h5>Christian</h5>
                                    <h5>Dior</h5>
                                </div>
                            </td>
                            <td>
                                <div className='center'><span className='rupee'>&#x20B9;2000</span></div>
                            </td>
                            <td>
                                <div className='flex_wl'>
                                    <span><Dash></Dash></span>
                                    <span>3</span>
                                    <span><Plus></Plus></span>
                                </div>
                            </td>
                            <td>
                                <div className='center'><span className='rupee'>&#x20B9;6000</span></div>
                            </td>
                            <td>
                                <div className='span_class'>
                                    <span className='span1 child1'><Cart></Cart></span>
                                    <span className='span1 child2'><Trash3></Trash3></span>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
            <Footer></Footer>
        </>
    )
}
